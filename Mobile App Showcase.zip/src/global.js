import { createGlobalStyle } from "styled-components";

export default createGlobalStyle`
    body {
      margin: 0; line-height: normal;
    }
:root {

/* fonts */
--font-mulish: Mulish;
--font-poppins: Poppins;
--font-inter: Inter;

/* font sizes */
--font-size-smi: 13px;
--font-size-sm: 14px;
--font-size-base: 16px;
--font-size-6xl: 25px;
--font-size-lg: 18px;
--font-size-11xl: 30px;
--font-size-xl: 20px;

/* Colors */
--color-white: #fff;
--color-black: #000;
--color-darkslategray-100: #434343;
--color-gray-100: #282727;
--color-lavender: rgba(223, 231, 241, 0.93);
--color-dimgray-100: #4d4d4d;
--color-paleturquoise: #b2edd1;
--color-lightsteelblue: #b8c8ff;

/* Border radiuses */
--br-31xl: 50px;
--br-xl: 20px;
--br-7xs: 6px;
--br-8xs: 5px;
--br-6xl: 25px;

}
`;
