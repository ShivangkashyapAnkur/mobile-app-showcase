import styled from "styled-components";

const PinkHeaderBg1Icon = styled.img`
  position: absolute;
  top: 0px;
  left: 543px;
  width: 897px;
  height: 649px;
  object-fit: cover;
`;
const GroupChild = styled.img`
  position: absolute;
  top: 0px;
  left: 0px;
  width: 1471px;
  height: 781.5px;
  object-fit: cover;
`;
const VectorIcon = styled.img`
  position: absolute;
  height: 7.17%;
  width: 80%;
  top: 16.58%;
  right: 13.6%;
  bottom: 76.24%;
  left: 6.4%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const VectorIcon1 = styled.img`
  position: absolute;
  height: 8.96%;
  width: 80%;
  top: 0%;
  right: 13.6%;
  bottom: 91.04%;
  left: 6.4%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const GroupItem = styled.img`
  position: absolute;
  height: 8.96%;
  width: 80%;
  top: 30.48%;
  right: 13.6%;
  bottom: 60.56%;
  left: 6.4%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const GroupInner = styled.img`
  position: absolute;
  top: 97px;
  left: 10.6px;
  max-width: 100%;
  overflow: hidden;
  height: 42px;
`;
const FollowUs = styled.div`
  position: absolute;
  top: 223.1px;
  left: 0px;
  line-height: 25px;
  text-transform: uppercase;
  transform: rotate(-90deg);
  transform-origin: 0 0;
`;
const VectorParent = styled.div`
  position: absolute;
  height: 43.83%;
  width: 1.98%;
  top: 0%;
  right: 0%;
  bottom: 56.17%;
  left: 98.02%;
`;
const BestMobile = styled.p`
  margin: 0;
`;
const BestMobileAppShowcaseContainer = styled.div`
  position: absolute;
  top: 174px;
  left: 3px;
  font-size: 65px;
  line-height: 75px;
  font-weight: 600;
`;
const AeneanDictumOdioContainer = styled.div`
  position: absolute;
  top: 361px;
  left: 0px;
  font-size: var(--font-size-base);
  line-height: 25px;
  color: #4e4e4e;
`;
const RectangleDiv = styled.div`
  position: absolute;
  top: 449px;
  left: 4px;
  border-radius: var(--br-31xl);
  background-color: var(--color-black);
  width: 198px;
  height: 60px;
`;
const ReadMore = styled.div`
  position: absolute;
  top: 466px;
  left: 61px;
  font-size: var(--font-size-lg);
  line-height: 25px;
  font-weight: 500;
  color: var(--color-white);
`;
const GroupContainer = styled.div`
  position: absolute;
  height: 65.13%;
  width: 86.02%;
  top: 18.23%;
  right: 6.16%;
  bottom: 16.63%;
  left: 7.82%;
`;
const HomeAboutUs = styled.div`
  position: absolute;
  top: 76.5px;
  left: 923px;
  font-size: var(--font-size-lg);
  line-height: 25px;
  font-weight: 600;
  color: #070707;
  white-space: pre-wrap;
`;
const GroupParent = styled.div`
  position: absolute;
  top: -41.5px;
  left: 0px;
  width: 1471px;
  height: 781.5px;
`;
const GroupIcon = styled.img`
  position: absolute;
  top: 0px;
  left: 129px;
  width: 1247px;
  height: 1518px;
  object-fit: contain;
`;
const GroupChild1 = styled.img`
  position: absolute;
  top: 0px;
  left: 0px;
  width: 312.7px;
  height: 482.6px;
`;
const GroupChild2 = styled.img`
  position: absolute;
  top: 13px;
  left: 14px;
  width: 312.7px;
  height: 482.6px;
`;
const VectorIcon2 = styled.img`
  position: absolute;
  height: 26.63%;
  width: 30.61%;
  top: 61.34%;
  right: 51.94%;
  bottom: 12.03%;
  left: 17.45%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const EllipseDiv = styled.div`
  position: absolute;
  top: 49px;
  left: 83px;
  border-radius: 50%;
  background-color: var(--color-white);
  border: 4px solid #c0f5cf;
  box-sizing: border-box;
  width: 174px;
  height: 174px;
`;
const Content1Icon = styled.img`
  position: absolute;
  top: 97px;
  left: 131px;
  width: 78px;
  height: 78px;
  object-fit: cover;
`;
const PerfectUiDesign = styled.div`
  position: absolute;
  top: 271px;
  left: 71px;
  line-height: 25px;
  text-transform: capitalize;
  font-weight: 500;
`;
const PraesentAcVehicula = styled.div`
  position: absolute;
  top: 334px;
  left: 38px;
  font-size: var(--font-size-sm);
  line-height: 20px;
  text-transform: capitalize;
  color: var(--color-black);
  text-align: center;
  display: inline-block;
  width: 263px;
  height: 61px;
`;
const GroupChild3 = styled.div`
  position: absolute;
  top: 421px;
  left: 143px;
  border-radius: 50%;
  background-color: var(--color-black);
  width: 49px;
  height: 49px;
`;
const VectorIcon3 = styled.img`
  position: absolute;
  height: 2.22%;
  width: 6.73%;
  top: 88.98%;
  right: 45.21%;
  bottom: 8.8%;
  left: 48.06%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const GroupChild4 = styled.img`
  position: absolute;
  height: 0.61%;
  width: 30%;
  top: 63.16%;
  right: 32.66%;
  bottom: 36.24%;
  left: 37.34%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const VectorGroup = styled.div`
  position: absolute;
  top: 277px;
  left: 0px;
  width: 326.7px;
  height: 495.6px;
  color: #050505;
`;
const GroupChild5 = styled.img`
  position: absolute;
  top: 10px;
  left: 20px;
  width: 312.7px;
  height: 482.6px;
`;
const VectorIcon4 = styled.img`
  position: absolute;
  height: 26.8%;
  width: 30.06%;
  top: 61.1%;
  right: 51.01%;
  bottom: 12.1%;
  left: 18.94%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const GroupChild6 = styled.div`
  position: absolute;
  top: 46px;
  left: 89px;
  border-radius: 50%;
  background-color: var(--color-white);
  border: 3px solid var(--color-lightsteelblue);
  box-sizing: border-box;
  width: 174px;
  height: 174px;
`;
const Content1Icon1 = styled.img`
  position: absolute;
  top: 94px;
  left: 137px;
  width: 78px;
  height: 78px;
  object-fit: cover;
`;
const PerfectUiDesign1 = styled.div`
  position: absolute;
  top: 268px;
  left: 77px;
  line-height: 25px;
  text-transform: capitalize;
  font-weight: 500;
`;
const PraesentAcVehicula1 = styled.div`
  position: absolute;
  top: 331px;
  left: 44px;
  font-size: var(--font-size-sm);
  line-height: 20px;
  text-transform: capitalize;
  text-align: center;
  display: inline-block;
  width: 263px;
  height: 61px;
`;
const GroupChild7 = styled.div`
  position: absolute;
  top: 418px;
  left: 149px;
  border-radius: 50%;
  background-color: var(--color-black);
  width: 49px;
  height: 49px;
`;
const VectorIcon5 = styled.img`
  position: absolute;
  height: 2.23%;
  width: 6.61%;
  top: 88.92%;
  right: 44.39%;
  bottom: 8.85%;
  left: 48.99%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const GroupChild8 = styled.img`
  position: absolute;
  height: 0.61%;
  width: 29.46%;
  top: 62.93%;
  right: 32.07%;
  bottom: 36.46%;
  left: 38.47%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const VectorContainer = styled.div`
  position: absolute;
  top: 280px;
  left: 395px;
  width: 332.7px;
  height: 492.6px;
`;
const Girl1Icon = styled.img`
  position: absolute;
  top: 0px;
  left: 1007px;
  width: 167px;
  height: 206px;
  object-fit: cover;
`;
const VectorParent1 = styled.div`
  position: absolute;
  top: 280px;
  left: 781px;
  width: 332.7px;
  height: 492.6px;
`;
const Dsd = styled.div`
  position: absolute;
  top: 129px;
  left: 513px;
  width: 104px;
  height: 16px;
`;
const GroupParent1 = styled.div`
  position: absolute;
  top: 93px;
  left: 0px;
  width: 1174px;
  height: 772.6px;
  text-align: left;
`;
const EngagingSpaciousContainer = styled.div`
  position: absolute;
  top: 148px;
  left: 441px;
  text-transform: capitalize;
  font-weight: 600;
  font-family: var(--font-inter);
`;
const Dsd11Icon = styled.img`
  position: absolute;
  top: 950px;
  left: 34px;
  width: 1047px;
  height: 15px;
  object-fit: cover;
`;
const HiseSedAugue = styled.div`
  position: absolute;
  top: 255px;
  left: 266px;
  font-size: var(--font-size-base);
  text-transform: capitalize;
  color: #8b8b8b;
  display: inline-block;
  width: 592px;
  height: 88px;
`;
const GroupDiv = styled.div`
  position: absolute;
  top: 643px;
  left: 161px;
  width: 1376px;
  height: 1518px;
  text-align: center;
  font-size: var(--font-size-6xl);
`;
const Asd1Icon = styled.img`
  position: absolute;
  top: 25px;
  left: 79px;
  width: 511.7px;
  height: 459.2px;
  object-fit: contain;
  display: none;
`;
const Zas1Icon = styled.img`
  position: absolute;
  top: 238.1px;
  left: 228.7px;
  width: 342px;
  height: 306px;
  object-fit: cover;
`;
const RemovebgPreview1Icon = styled.img`
  position: absolute;
  top: 46px;
  left: 46px;
  width: 500px;
  height: 500px;
  object-fit: cover;
`;
const EasyAndPerfectContainer = styled.div`
  position: absolute;
  top: 46px;
  left: 651px;
  line-height: 40px;
  text-transform: capitalize;
  font-weight: 600;
`;
const AliquamAliquetPurusContainer = styled.div`
  position: absolute;
  top: 155px;
  left: 652px;
  font-size: var(--font-size-base);
  line-height: 25px;
  text-transform: capitalize;
  color: #454545;
  display: inline-block;
  width: 569px;
  height: 342px;
`;
const GroupChild9 = styled.div`
  position: absolute;
  top: 387px;
  left: 649px;
  border-radius: var(--br-31xl);
  background-color: var(--color-black);
  width: 198px;
  height: 60px;
`;
const Xc21Icon = styled.img`
  position: absolute;
  top: 0px;
  left: 0px;
  width: 145px;
  height: 154px;
  object-fit: cover;
`;
const ReadMore1 = styled.div`
  position: absolute;
  top: 404px;
  left: 706px;
  font-size: var(--font-size-lg);
  line-height: 25px;
  font-weight: 500;
  color: var(--color-white);
`;
const GroupChild10 = styled.img`
  position: absolute;
  top: 137px;
  left: 654px;
  max-height: 100%;
  width: 188px;
`;
const Asd1Parent = styled.div`
  position: absolute;
  top: 1661px;
  left: 54px;
  width: 1221px;
  height: 546px;
  font-size: var(--font-size-11xl);
`;
const GroupChild11 = styled.div`
  position: absolute;
  top: 0px;
  left: 0px;
  background: linear-gradient(
    180deg,
    rgba(137, 229, 145, 0.02),
    rgba(137, 229, 145, 0.13) 50%,
    rgba(137, 229, 145, 0.02)
  );
  width: 1457px;
  height: 848px;
`;
const GroupChild12 = styled.div`
  position: absolute;
  top: 0px;
  left: 0px;
  box-shadow: 0px 0px 35px rgba(0, 0, 0, 0.11);
  border-radius: var(--br-6xl);
  background-color: var(--color-white);
  width: 550px;
  height: 152px;
`;
const GroupChild13 = styled.div`
  position: absolute;
  top: 45px;
  left: 45px;
  border-radius: 50%;
  background-color: rgba(23, 152, 180, 0.26);
  width: 62px;
  height: 62px;
`;
const GroupChild14 = styled.div`
  position: absolute;
  top: 35px;
  left: 35px;
  border-radius: 50%;
  background-color: rgba(23, 152, 180, 0.1);
  width: 82px;
  height: 82px;
`;
const GroupChild15 = styled.div`
  position: absolute;
  top: 53px;
  left: 53px;
  border-radius: 50%;
  background-color: #1798b4;
  width: 46px;
  height: 46px;
`;
const VectorIcon6 = styled.img`
  position: absolute;
  height: 15.79%;
  width: 4.21%;
  top: 42.11%;
  right: 84.56%;
  bottom: 42.11%;
  left: 11.23%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const MakeAProfile = styled.div`
  position: absolute;
  top: 32px;
  left: 147px;
  line-height: 25px;
  font-weight: 500;
`;
const AliquamVariusLigula = styled.div`
  position: absolute;
  top: 69px;
  left: 148px;
  font-size: var(--font-size-base);
  line-height: 20px;
  color: var(--color-darkslategray-100);
  display: inline-block;
  width: 422px;
  height: 70px;
`;
const RectangleGroup = styled.div`
  position: absolute;
  top: 406px;
  left: 136px;
  width: 570px;
  height: 152px;
`;
const GroupChild16 = styled.div`
  position: absolute;
  top: 45px;
  left: 45px;
  border-radius: 50%;
  background-color: rgba(241, 177, 26, 0.26);
  width: 62px;
  height: 62px;
`;
const GroupChild17 = styled.div`
  position: absolute;
  top: 35px;
  left: 35px;
  border-radius: 50%;
  background-color: rgba(241, 177, 26, 0.1);
  width: 82px;
  height: 82px;
`;
const GroupChild18 = styled.div`
  position: absolute;
  top: 53px;
  left: 53px;
  border-radius: 50%;
  background-color: #f1b11a;
  width: 46px;
  height: 46px;
`;
const RectangleContainer = styled.div`
  position: absolute;
  top: 586px;
  left: 137px;
  width: 570px;
  height: 152px;
`;
const GroupChild19 = styled.img`
  position: absolute;
  top: 34px;
  left: 29px;
  width: 82px;
  height: 82px;
`;
const MakeAProfile1 = styled.div`
  position: absolute;
  top: 29px;
  left: 144px;
  line-height: 25px;
  font-weight: 500;
`;
const AliquamVariusLigula1 = styled.div`
  position: absolute;
  top: 66px;
  left: 145px;
  font-size: var(--font-size-base);
  line-height: 20px;
  color: var(--color-darkslategray-100);
  display: inline-block;
  width: 422px;
  height: 70px;
`;
const RectangleParent = styled.div`
  position: absolute;
  top: 230px;
  left: 137px;
  width: 567px;
  height: 152px;
`;
const Dsd3Icon = styled.img`
  position: absolute;
  top: 176px;
  left: 137px;
  width: 104px;
  height: 16px;
  object-fit: cover;
`;
const HowDoesThis = styled.div`
  position: absolute;
  top: 132px;
  left: 137px;
  font-size: var(--font-size-11xl);
  line-height: 25px;
  font-weight: 600;
`;
const RemovebgPreview1Icon1 = styled.img`
  position: absolute;
  top: 160px;
  left: 729px;
  width: 630px;
  height: 630px;
  object-fit: cover;
`;
const RectangleParent1 = styled.div`
  position: absolute;
  top: 2278px;
  left: 0px;
  width: 1457px;
  height: 848px;
  font-size: var(--font-size-6xl);
`;
const DesignedWorkedContainer = styled.div`
  position: absolute;
  top: 3197px;
  left: 743px;
  font-size: var(--font-size-11xl);
  line-height: 45px;
  font-weight: 600;
`;
const Sa1Icon = styled.img`
  position: absolute;
  top: 3151px;
  left: 97px;
  width: 128px;
  height: 411px;
  object-fit: cover;
`;
const Sa11Icon = styled.img`
  position: absolute;
  top: 3151px;
  left: 1130px;
  width: 182px;
  height: 489px;
  object-fit: cover;
`;
const FreelanceManIsWorkingRemovIcon = styled.img`
  position: absolute;
  top: 3186px;
  left: 166px;
  width: 500px;
  height: 500px;
  object-fit: cover;
`;
const Desktop2Child = styled.div`
  position: absolute;
  top: 3338px;
  left: 743px;
  box-shadow: 0px 5px 5px -1px rgba(0, 0, 0, 0.1);
  border-radius: 0px 0px var(--br-8xs) var(--br-8xs);
  background-color: var(--color-white);
  width: 538px;
  height: 151px;
`;
const Desktop2Item = styled.div`
  position: absolute;
  top: 3303px;
  left: 743px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.13);
  border-radius: var(--br-7xs);
  background-color: var(--color-paleturquoise);
  width: 538px;
  height: 54px;
`;
const AliquamVariusLigula2 = styled.div`
  position: absolute;
  top: 3308px;
  left: 767px;
  font-size: var(--font-size-xl);
  line-height: 45px;
  font-weight: 500;
`;
const Desktop2Inner = styled.div`
  position: absolute;
  top: 3506px;
  left: 743px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.13);
  border-radius: var(--br-7xs);
  background-color: var(--color-paleturquoise);
  width: 538px;
  height: 54px;
`;
const SuspendisseVitaeVarius = styled.div`
  position: absolute;
  top: 3511px;
  left: 767px;
  font-size: var(--font-size-xl);
  line-height: 45px;
  font-weight: 500;
`;
const Desktop2Child1 = styled.div`
  position: absolute;
  top: 3576px;
  left: 743px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.13);
  border-radius: var(--br-7xs);
  background-color: var(--color-paleturquoise);
  width: 538px;
  height: 54px;
`;
const AliquamAliquetPurus = styled.div`
  position: absolute;
  top: 3581px;
  left: 767px;
  font-size: var(--font-size-xl);
  line-height: 45px;
  font-weight: 500;
`;
const LoremIpsumIsSimply = styled.div`
  position: absolute;
  top: 3370px;
  left: 760px;
  line-height: 20px;
  color: #5d5d5d;
  display: inline-block;
  width: 504px;
  height: 109px;
`;
const Dsd21Icon = styled.img`
  position: absolute;
  top: 0px;
  left: 692px;
  width: 104px;
  height: 16px;
  object-fit: cover;
`;
const GroupChild20 = styled.div`
  position: absolute;
  top: 2924px;
  left: 0px;
  background-color: var(--color-paleturquoise);
  width: 1453px;
  height: 928px;
`;
const Screenshot131Icon = styled.img`
  position: absolute;
  top: 3233px;
  left: 1167px;
  width: 265px;
  height: 455px;
  object-fit: cover;
`;
const Screenshot171Icon = styled.img`
  position: absolute;
  top: 3233px;
  left: 884px;
  width: 254px;
  height: 452px;
  object-fit: cover;
`;
const Screenshot161Icon = styled.img`
  position: absolute;
  top: 3233px;
  left: 33px;
  width: 255px;
  height: 452px;
  object-fit: cover;
`;
const Screenshot141Icon = styled.img`
  position: absolute;
  top: 3233px;
  left: 303px;
  width: 255px;
  height: 452px;
  object-fit: cover;
`;
const Screenshot151Icon = styled.img`
  position: absolute;
  top: 3233px;
  left: 593px;
  width: 254px;
  height: 452px;
  object-fit: cover;
`;
const PhoneMokeup21Icon = styled.img`
  position: absolute;
  top: 3162px;
  left: 573px;
  width: 295px;
  height: 593px;
  object-fit: cover;
`;
const AppScreenshots = styled.div`
  position: absolute;
  top: 2984px;
  left: 586px;
  line-height: 40px;
  text-transform: capitalize;
  font-weight: 600;
`;
const SaepeQuoLabore = styled.div`
  position: absolute;
  top: 3077px;
  left: 471px;
  font-size: var(--font-size-base);
  line-height: 20px;
  text-transform: capitalize;
  color: #10511f;
  display: inline-block;
  width: 498px;
  height: 102px;
`;
const Dsd22Icon = styled.img`
  position: absolute;
  top: 3037px;
  left: 663px;
  width: 104px;
  height: 16px;
  object-fit: cover;
`;
const VectorIcon7 = styled.img`
  position: absolute;
  height: 0.39%;
  width: 1.03%;
  top: 98.03%;
  right: 51.62%;
  bottom: 1.58%;
  left: 47.35%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const VectorIcon8 = styled.img`
  position: absolute;
  height: 0.39%;
  width: 1.03%;
  top: 98.03%;
  right: 49.76%;
  bottom: 1.58%;
  left: 49.21%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const VectorIcon9 = styled.img`
  position: absolute;
  height: 0.39%;
  width: 1.03%;
  top: 98.03%;
  right: 47.9%;
  bottom: 1.58%;
  left: 51.07%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const Dsd21Parent = styled.div`
  position: absolute;
  top: 860px;
  left: -7px;
  width: 1453px;
  height: 3852px;
  text-align: center;
  font-size: var(--font-size-11xl);
`;
const Desktop2Child2 = styled.div`
  position: absolute;
  top: 4712px;
  left: -6px;
  background-color: #fefff6;
  width: 1452px;
  height: 742px;
`;
const VectorIcon10 = styled.img`
  position: absolute;
  height: 0.66%;
  width: 1.53%;
  top: 85.45%;
  right: 90%;
  bottom: 13.89%;
  left: 8.47%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: contain;
`;
const VectorIcon11 = styled.img`
  position: absolute;
  height: 0.66%;
  width: 1.53%;
  top: 85.95%;
  right: 9.58%;
  bottom: 13.39%;
  left: 88.89%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const ReviewsFromStudents = styled.div`
  position: absolute;
  top: 4776px;
  left: 541px;
  font-size: var(--font-size-11xl);
  line-height: 40px;
  text-transform: capitalize;
  font-weight: 600;
  text-align: center;
`;
const Dsd22Icon1 = styled.img`
  position: absolute;
  top: 4830px;
  left: 665px;
  width: 104px;
  height: 16px;
  object-fit: cover;
`;
const GroupChild21 = styled.div`
  position: absolute;
  top: 0px;
  left: 0px;
  box-shadow: 0px 0px 15px rgba(101, 184, 125, 0.28);
  border-radius: var(--br-xl);
  background-color: var(--color-white);
  width: 500px;
  height: 306px;
`;
const JennyWilson = styled.div`
  position: absolute;
  top: 200px;
  left: 228px;
  line-height: 20px;
  text-transform: capitalize;
  font-weight: 600;
`;
const VectorIcon12 = styled.img`
  position: absolute;
  height: 3.27%;
  width: 2%;
  top: 73.86%;
  right: 41%;
  bottom: 22.88%;
  left: 57%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const VectorIcon13 = styled.img`
  position: absolute;
  height: 3.27%;
  width: 2%;
  top: 73.86%;
  right: 43.8%;
  bottom: 22.88%;
  left: 54.2%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const VectorIcon14 = styled.img`
  position: absolute;
  height: 3.27%;
  width: 2%;
  top: 73.86%;
  right: 46.8%;
  bottom: 22.88%;
  left: 51.2%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const VectorIcon15 = styled.img`
  position: absolute;
  height: 3.27%;
  width: 2%;
  top: 73.86%;
  right: 49.6%;
  bottom: 22.88%;
  left: 48.4%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const VectorIcon16 = styled.img`
  position: absolute;
  height: 3.27%;
  width: 2%;
  top: 73.86%;
  right: 52.4%;
  bottom: 22.88%;
  left: 45.6%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const Aro1Icon = styled.img`
  position: absolute;
  top: 139px;
  left: 130px;
  width: 83px;
  height: 61px;
  object-fit: cover;
`;
const GroupChild22 = styled.img`
  position: absolute;
  top: 168px;
  left: 355.5px;
  width: 23px;
  height: 21px;
`;
const InvertedCommasTop1Icon = styled.img`
  position: absolute;
  top: 181px;
  left: 36px;
  width: 66px;
  height: 63px;
  object-fit: cover;
`;
const PerSedMattis = styled.div`
  position: absolute;
  top: 55px;
  left: 48px;
  line-height: 20px;
  text-transform: capitalize;
  color: var(--color-dimgray-100);
  display: inline-block;
  width: 412px;
  height: 102px;
`;
const GroupChild23 = styled.div`
  position: absolute;
  top: 176px;
  left: 351px;
  border-radius: 50%;
  background-color: var(--color-lavender);
  width: 92px;
  height: 92px;
`;
const MaskGroupIcon = styled.img`
  position: absolute;
  top: 183px;
  left: 358px;
  width: 78px;
  height: 78px;
  object-fit: cover;
`;
const RectangleParent2 = styled.div`
  position: absolute;
  top: 4972px;
  left: 186px;
  width: 500px;
  height: 306px;
`;
const RectangleParent3 = styled.div`
  position: absolute;
  top: 4972px;
  left: 734px;
  width: 500px;
  height: 306px;
`;
const Desktop2Child3 = styled.div`
  position: absolute;
  top: 5452px;
  left: -12px;
  background-color: var(--color-gray-100);
  width: 1485px;
  height: 516px;
  display: none;
`;
const Desktop2Child4 = styled.div`
  position: absolute;
  top: 5452px;
  left: -12px;
  background-color: var(--color-gray-100);
  width: 1485px;
  height: 500px;
`;
const QuickLinksUseful = styled.div`
  position: absolute;
  top: 5640px;
  left: 554px;
  font-size: var(--font-size-lg);
  line-height: 20px;
  text-transform: capitalize;
  font-weight: 600;
  font-family: var(--font-mulish);
  color: var(--color-white);
  white-space: pre-wrap;
`;
const Desktop2Child5 = styled.div`
  position: absolute;
  top: 5386px;
  left: 182px;
  border-radius: 15px;
  background-color: #b0eeaa;
  width: 1052px;
  height: 200px;
`;
const Desktop2Child6 = styled.img`
  position: absolute;
  top: 5414px;
  left: 704px;
  max-width: 100%;
  overflow: hidden;
  height: 146px;
`;
const SubscribeOurNewsletter = styled.b`
  position: absolute;
  top: 5423px;
  left: 237px;
  font-size: var(--font-size-6xl);
  line-height: 20px;
  text-transform: capitalize;
  font-family: var(--font-mulish);
`;
const ElementumExSimilique = styled.div`
  position: absolute;
  top: 5475px;
  left: 237px;
  font-size: var(--font-size-base);
  line-height: 20px;
  text-transform: capitalize;
  color: #313230;
  display: inline-block;
  width: 392px;
  height: 78px;
`;
const Desktop2Child7 = styled.img`
  position: absolute;
  top: 5459px;
  left: 240px;
  max-height: 100%;
  width: 165px;
`;
const Desktop2Child8 = styled.div`
  position: absolute;
  top: 5454px;
  left: 748px;
  border-radius: var(--br-31xl);
  background-color: var(--color-white);
  width: 438px;
  height: 60px;
`;
const Desktop2Child9 = styled.div`
  position: absolute;
  top: 5453px;
  left: 1050px;
  border-radius: var(--br-31xl);
  background-color: var(--color-black);
  width: 136px;
  height: 61px;
`;
const Subsribe = styled.div`
  position: absolute;
  top: 5474px;
  left: 1082px;
  font-size: var(--font-size-base);
  line-height: 20px;
  text-transform: capitalize;
  font-weight: 500;
  color: var(--color-white);
`;
const Desktop2Child10 = styled.img`
  position: absolute;
  height: 0.05%;
  width: 3.89%;
  top: 95.23%;
  right: 57.64%;
  bottom: 4.72%;
  left: 38.47%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const Desktop2Child11 = styled.img`
  position: absolute;
  height: 0.05%;
  width: 3.89%;
  top: 95.23%;
  right: 41.67%;
  bottom: 4.72%;
  left: 54.44%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const Desktop2Child12 = styled.img`
  position: absolute;
  height: 0.05%;
  width: 3.89%;
  top: 95.23%;
  right: 26.39%;
  bottom: 4.72%;
  left: 69.72%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const HomeAboutUsContainer = styled.div`
  position: absolute;
  top: 0px;
  left: 14px;
  line-height: 30px;
  text-transform: capitalize;
  font-weight: 600;
`;
const GroupChild24 = styled.img`
  position: absolute;
  top: 10px;
  left: 0px;
  max-width: 100%;
  overflow: hidden;
  height: 12px;
`;
const GroupChild25 = styled.img`
  position: absolute;
  top: 38px;
  left: 0px;
  max-width: 100%;
  overflow: hidden;
  height: 12px;
`;
const GroupChild26 = styled.img`
  position: absolute;
  top: 70px;
  left: 0px;
  max-width: 100%;
  overflow: hidden;
  height: 12px;
`;
const GroupChild27 = styled.img`
  position: absolute;
  top: 99px;
  left: 0px;
  max-width: 100%;
  overflow: hidden;
  height: 12px;
`;
const HomeAboutUsCareersNewsAParent = styled.div`
  position: absolute;
  top: 5691px;
  left: 560px;
  width: 118px;
  height: 120px;
  color: var(--color-white);
  font-family: var(--font-mulish);
`;
const HelpCenterContactUsFaqParParent = styled.div`
  position: absolute;
  top: 5691px;
  left: 787px;
  width: 137px;
  height: 120px;
  color: var(--color-white);
  font-family: var(--font-mulish);
`;
const Am = styled.div`
  position: absolute;
  top: 5691px;
  left: 1030px;
  font-size: var(--font-size-smi);
  line-height: 20px;
  text-transform: capitalize;
  font-weight: 600;
  font-family: var(--font-mulish);
  color: var(--color-white);
`;
const AutQuaeConvallis = styled.div`
  position: absolute;
  top: 5724px;
  left: 1030px;
  font-size: var(--font-size-smi);
  line-height: 18px;
  text-transform: capitalize;
  font-weight: 600;
  font-family: var(--font-mulish);
  color: var(--color-white);
  display: inline-block;
  width: 206px;
  height: 52px;
`;
const VectorIcon17 = styled.img`
  position: absolute;
  height: 0.24%;
  width: 0.97%;
  top: 95.68%;
  right: 29.79%;
  bottom: 4.08%;
  left: 69.24%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const Desktop2Child13 = styled.img`
  position: absolute;
  height: 0.3%;
  width: 0.97%;
  top: 96.2%;
  right: 29.72%;
  bottom: 3.5%;
  left: 69.31%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
`;
const Desktop2Child14 = styled.img`
  position: absolute;
  top: 5789px;
  left: 1030px;
  width: 12px;
  height: 12px;
`;
const Desktop2Child15 = styled.img`
  position: absolute;
  top: 5789px;
  left: 1050px;
  width: 12px;
  height: 12px;
`;
const Desktop2Child16 = styled.img`
  position: absolute;
  top: 5789px;
  left: 1071px;
  width: 12px;
  height: 12px;
`;
const VeroTemporMorbi = styled.div`
  position: absolute;
  top: 5740px;
  left: 198px;
  font-size: var(--font-size-smi);
  line-height: 18px;
  text-transform: capitalize;
  font-weight: 600;
  font-family: var(--font-mulish);
  color: var(--color-white);
  display: inline-block;
  width: 287px;
  height: 53px;
`;
const Desktop2Child17 = styled.div`
  position: absolute;
  top: 5868px;
  left: 0px;
  background-color: var(--color-black);
  width: 1440px;
  height: 84px;
`;
const PrivacyPolicy = styled.div`
  position: absolute;
  top: 5903px;
  left: 863px;
  font-size: var(--font-size-smi);
  line-height: 18px;
  font-weight: 600;
  font-family: var(--font-mulish);
  color: var(--color-white);
  white-space: pre-wrap;
`;
const Copyright = styled.div`
  position: absolute;
  top: 5900px;
  left: 182px;
  font-size: var(--font-size-smi);
  line-height: 18px;
  font-weight: 600;
  font-family: var(--font-mulish);
  color: var(--color-white);
`;
const DesktopRoot = styled.div`
  width: 100%;
  position: relative;
  background-color: var(--color-white);
  height: 5952px;
  overflow: hidden;
  text-align: left;
  font-size: var(--font-size-sm);
  color: var(--color-black);
  font-family: var(--font-poppins);
`;

const Desktop = () => {
  return (
    <DesktopRoot>
      <PinkHeaderBg1Icon alt="" src="/pinkheaderbg-1@2x.png" />
      <GroupParent>
        <GroupChild alt="" src="/group-2@2x.png" />
        <GroupContainer>
          <VectorParent>
            <VectorIcon alt="" src="/vector.svg" />
            <VectorIcon1 alt="" src="/vector1.svg" />
            <GroupItem alt="" src="/group-4.svg" />
            <GroupInner alt="" src="/vector-5.svg" />
            <FollowUs>Follow Us</FollowUs>
          </VectorParent>
          <BestMobileAppShowcaseContainer>
            <BestMobile>{`Best Mobile `}</BestMobile>
            <BestMobile>App Showcase</BestMobile>
          </BestMobileAppShowcaseContainer>
          <AeneanDictumOdioContainer>
            <BestMobile>{`Aenean dictum odio dapibus turpis dapibus vestibulum. Mauris quis massa `}</BestMobile>
            <BestMobile>
              nisi. Nullam porta lorem at volutpat euismod. Proin in ex nunc.
            </BestMobile>
          </AeneanDictumOdioContainer>
          <RectangleDiv />
          <ReadMore>Read More</ReadMore>
        </GroupContainer>
        <HomeAboutUs>Home About Us Features Contact</HomeAboutUs>
      </GroupParent>
      <GroupDiv>
        <GroupIcon alt="" src="/group-63@2x.png" />
        <GroupParent1>
          <VectorGroup>
            <GroupChild1 alt="" src="/vector-7.svg" />
            <GroupChild2 alt="" src="/vector-6.svg" />
            <VectorIcon2 alt="" src="/vector2.svg" />
            <EllipseDiv />
            <Content1Icon alt="" src="/content-1@2x.png" />
            <PerfectUiDesign>Perfect UI Design</PerfectUiDesign>
            <PraesentAcVehicula>
              Praesent ac vehicula sapien. Sed sollicitudin molestie consequat.
              Ut vitae ante ut mi vehicula vulputate.
            </PraesentAcVehicula>
            <GroupChild3 />
            <VectorIcon3 alt="" src="/vector3.svg" />
            <GroupChild4 alt="" src="/group-5.svg" />
          </VectorGroup>
          <VectorContainer>
            <GroupChild1 alt="" src="/vector-7.svg" />
            <GroupChild5 alt="" src="/vector-61.svg" />
            <VectorIcon4 alt="" src="/vector4.svg" />
            <GroupChild6 />
            <Content1Icon1 alt="" src="/content-1@2x.png" />
            <PerfectUiDesign1>Perfect UI Design</PerfectUiDesign1>
            <PraesentAcVehicula1>
              Praesent ac vehicula sapien. Sed sollicitudin molestie consequat.
              Ut vitae ante ut mi vehicula vulputate.
            </PraesentAcVehicula1>
            <GroupChild7 />
            <VectorIcon5 alt="" src="/vector3.svg" />
            <GroupChild8 alt="" src="/group-5.svg" />
          </VectorContainer>
          <Girl1Icon alt="" src="/girl-1@2x.png" />
          <VectorParent1>
            <GroupChild1 alt="" src="/vector-7.svg" />
            <GroupChild5 alt="" src="/vector-6.svg" />
            <GroupChild6 />
            <VectorIcon4 alt="" src="/vector5.svg" />
            <Content1Icon1 alt="" src="/content-1@2x.png" />
            <PerfectUiDesign1>Perfect UI Design</PerfectUiDesign1>
            <PraesentAcVehicula1>
              Praesent ac vehicula sapien. Sed sollicitudin molestie consequat.
              Ut vitae ante ut mi vehicula vulputate.
            </PraesentAcVehicula1>
            <GroupChild7 />
            <VectorIcon5 alt="" src="/vector3.svg" />
            <GroupChild8 alt="" src="/group-5.svg" />
          </VectorParent1>
          <Dsd />
        </GroupParent1>
        <EngagingSpaciousContainer>
          <BestMobile>{`Engaging & Spacious `}</BestMobile>
          <BestMobile>School Campus</BestMobile>
        </EngagingSpaciousContainer>
        <Dsd11Icon alt="" src="/dsd1-1@2x.png" />
        <HiseSedAugue>
          Hise sed augue vitae felis pellentesque varius nec quis nunc. Morbi
          mauris augue, pulvinar quis luctus eget. Phasellus gravida lacus quis
          eros lobortis, nec dapibus quam gravida.
        </HiseSedAugue>
      </GroupDiv>
      <Asd1Parent>
        <Asd1Icon alt="" src="/asd-1@2x.png" />
        <Zas1Icon alt="" src="/zas-1@2x.png" />
        <RemovebgPreview1Icon alt="" src="/4667617removebgpreview-1@2x.png" />
        <EasyAndPerfectContainer>
          <BestMobile>{`Easy And Perfect Solution For `}</BestMobile>
          <BestMobile>Your Business App</BestMobile>
        </EasyAndPerfectContainer>
        <AliquamAliquetPurusContainer>
          <BestMobile>
            Aliquam aliquet purus a est consequat lobortis. Etiam vehicula
            suscipit purus, eget ullamcorper augue blandit vitae. Ut eu euismod
            felis. Etiam at varius quam. Vivamus lacinia pulvinar turpis in
            suscipit. Aenean mattis enim ut pretium gravida. Sed fermentum a
            lacus bibendum convallis.
          </BestMobile>
          <BestMobile>&nbsp;</BestMobile>
          <BestMobile>
            Consequat purus aliquet a est aliquam lobortis. Etiam vehicula
            suscipit purus, eget ullamcorper augue blandit vitae....
          </BestMobile>
        </AliquamAliquetPurusContainer>
        <GroupChild9 />
        <Xc21Icon alt="" src="/xc2-1@2x.png" />
        <ReadMore1>Read More</ReadMore1>
        <GroupChild10 alt="" src="/vector-13.svg" />
      </Asd1Parent>
      <RectangleParent1>
        <GroupChild11 />
        <RectangleGroup>
          <GroupChild12 />
          <GroupChild13 />
          <GroupChild14 />
          <GroupChild15 />
          <VectorIcon6 alt="" src="/vector6.svg" />
          <MakeAProfile>Make A Profile</MakeAProfile>
          <AliquamVariusLigula>
            Aliquam varius ligula nec leo tempus porta. Vestibulum suscipit leo
            at nunc imperdiet, quis lacinia nisi euismod.
          </AliquamVariusLigula>
        </RectangleGroup>
        <RectangleContainer>
          <GroupChild12 />
          <GroupChild16 />
          <GroupChild17 />
          <GroupChild18 />
          <VectorIcon6 alt="" src="/vector6.svg" />
          <MakeAProfile>Make A Profile</MakeAProfile>
          <AliquamVariusLigula>
            Aliquam varius ligula nec leo tempus porta. Vestibulum suscipit leo
            at nunc imperdiet, quis lacinia nisi euismod.
          </AliquamVariusLigula>
        </RectangleContainer>
        <RectangleParent>
          <GroupChild12 />
          <GroupChild19 alt="" src="/group-68.svg" />
          <MakeAProfile1>Make A Profile</MakeAProfile1>
          <AliquamVariusLigula1>
            Aliquam varius ligula nec leo tempus porta. Vestibulum suscipit leo
            at nunc imperdiet, quis lacinia nisi euismod.
          </AliquamVariusLigula1>
        </RectangleParent>
        <Dsd3Icon alt="" src="/dsd-3@2x.png" />
        <HowDoesThis>How does This App Work?</HowDoesThis>
        <RemovebgPreview1Icon1 alt="" src="/4934434removebgpreview-1@2x.png" />
      </RectangleParent1>
      <DesignedWorkedContainer>
        <BestMobile>{`Designed & Worked By The Latest `}</BestMobile>
        <BestMobile>Partners</BestMobile>
      </DesignedWorkedContainer>
      <Sa1Icon alt="" src="/sa-1@2x.png" />
      <Sa11Icon alt="" src="/sa1-1@2x.png" />
      <FreelanceManIsWorkingRemovIcon
        alt=""
        src="/freelancemanisworkingremovebgpreview-1@2x.png"
      />
      <Desktop2Child />
      <Desktop2Item />
      <AliquamVariusLigula2>
        Aliquam varius ligula nec leo tempus porta.
      </AliquamVariusLigula2>
      <Desktop2Inner />
      <SuspendisseVitaeVarius>
        Suspendisse vitae varius diam, a vulputate urna.
      </SuspendisseVitaeVarius>
      <Desktop2Child1 />
      <AliquamAliquetPurus>
        Aliquam aliquet purus eget lacus pretium.
      </AliquamAliquetPurus>
      <LoremIpsumIsSimply>
        Lorem Ipsum is simply dummy text of the printing and typesetting
        industry. Lorem Ipsum has been the industry's standard dummy text ever
        since the 1500s, when an unknown printer took a galley of type and
        scrambled it to make a type specimen book. It has survived not only five
        centuries, but also the leap into electronic typesetting,
      </LoremIpsumIsSimply>
      <Dsd21Parent>
        <Dsd21Icon alt="" src="/dsd2-1@2x.png" />
        <GroupChild20 />
        <Screenshot131Icon alt="" src="/screenshot13-1@2x.png" />
        <Screenshot171Icon alt="" src="/screenshot17-1@2x.png" />
        <Screenshot161Icon alt="" src="/screenshot16-1@2x.png" />
        <Screenshot141Icon alt="" src="/screenshot14-1@2x.png" />
        <Screenshot151Icon alt="" src="/screenshot15-1@2x.png" />
        <PhoneMokeup21Icon alt="" src="/phonemokeup2-1@2x.png" />
        <AppScreenshots>App Screenshots</AppScreenshots>
        <SaepeQuoLabore>
          Saepe quo labore aenean dictumst expedita commodi auctor, nisl, lorem
          iusto feugiat nemo reiciendis laboris.
        </SaepeQuoLabore>
        <Dsd22Icon alt="" src="/dsd2-1@2x.png" />
        <VectorIcon7 alt="" src="/vector7.svg" />
        <VectorIcon8 alt="" src="/vector8.svg" />
        <VectorIcon9 alt="" src="/vector8.svg" />
      </Dsd21Parent>
      <Desktop2Child2 />
      <VectorIcon10 alt="" src="/vector9.svg" />
      <VectorIcon11 alt="" src="/vector10.svg" />
      <ReviewsFromStudents>Review's From Students</ReviewsFromStudents>
      <Dsd22Icon1 alt="" src="/dsd2-1@2x.png" />
      <RectangleParent2>
        <GroupChild21 />
        <JennyWilson>Jenny Wilson</JennyWilson>
        <VectorIcon12 alt="" src="/vector11.svg" />
        <VectorIcon13 alt="" src="/vector11.svg" />
        <VectorIcon14 alt="" src="/vector12.svg" />
        <VectorIcon15 alt="" src="/vector12.svg" />
        <VectorIcon16 alt="" src="/vector12.svg" />
        <Aro1Icon alt="" src="/aro-1@2x.png" />
        <GroupChild22 alt="" src="/vector-14.svg" />
        <InvertedCommasTop1Icon alt="" src="/invertedcommastop-1@2x.png" />
        <PerSedMattis>
          Per sed, mattis. Integer viverra euismod maecenas incidunt, phasellus
          consequatur aliquam nihil temporibus in assumenda? Aute praesentium
          fugiat. Perspiciatis, ultrices deserunt convallis, eius at non.
        </PerSedMattis>
        <GroupChild23 />
        <MaskGroupIcon alt="" src="/mask-group@2x.png" />
      </RectangleParent2>
      <RectangleParent3>
        <GroupChild21 />
        <JennyWilson>Jenny Wilson</JennyWilson>
        <VectorIcon12 alt="" src="/vector11.svg" />
        <VectorIcon13 alt="" src="/vector11.svg" />
        <VectorIcon14 alt="" src="/vector12.svg" />
        <VectorIcon15 alt="" src="/vector12.svg" />
        <VectorIcon16 alt="" src="/vector12.svg" />
        <Aro1Icon alt="" src="/aro-1@2x.png" />
        <GroupChild22 alt="" src="/vector-14.svg" />
        <InvertedCommasTop1Icon alt="" src="/invertedcommastop-1@2x.png" />
        <PerSedMattis>
          Per sed, mattis. Integer viverra euismod maecenas incidunt, phasellus
          consequatur aliquam nihil temporibus in assumenda? Aute praesentium
          fugiat. Perspiciatis, ultrices deserunt convallis, eius at non.
        </PerSedMattis>
        <GroupChild23 />
        <MaskGroupIcon alt="" src="/mask-group@2x.png" />
      </RectangleParent3>
      <Desktop2Child3 />
      <Desktop2Child4 />
      <QuickLinksUseful>Quick LInks Useful Links School Hours</QuickLinksUseful>
      <Desktop2Child5 />
      <Desktop2Child6 alt="" src="/vector-16.svg" />
      <SubscribeOurNewsletter>
        Subscribe Our Newsletter !
      </SubscribeOurNewsletter>
      <ElementumExSimilique>
        Elementum ex similique sollicitudin eveniet sem eveniet proin, iste
        euismod! Quia! Fugiat molestie leo placerat, tenetur.
      </ElementumExSimilique>
      <Desktop2Child7 alt="" src="/vector-15.svg" />
      <Desktop2Child8 />
      <Desktop2Child9 />
      <Subsribe>SUBSRIBE</Subsribe>
      <Desktop2Child10 alt="" src="/group-51.svg" />
      <Desktop2Child11 alt="" src="/group-51.svg" />
      <Desktop2Child12 alt="" src="/group-51.svg" />
      <HomeAboutUsCareersNewsAParent>
        <HomeAboutUsContainer>
          <BestMobile>{`Home `}</BestMobile>
          <BestMobile>About us</BestMobile>
          <BestMobile>Careers</BestMobile>
          <BestMobile>{`News & Articles`}</BestMobile>
        </HomeAboutUsContainer>
        <GroupChild24 alt="" src="/vector-17.svg" />
        <GroupChild25 alt="" src="/vector-17.svg" />
        <GroupChild26 alt="" src="/vector-17.svg" />
        <GroupChild27 alt="" src="/vector-17.svg" />
      </HomeAboutUsCareersNewsAParent>
      <HelpCenterContactUsFaqParParent>
        <HomeAboutUsContainer>
          <BestMobile>Help Center</BestMobile>
          <BestMobile>Contact Us</BestMobile>
          <BestMobile>FAQ</BestMobile>
          <BestMobile>Parent Community</BestMobile>
        </HomeAboutUsContainer>
        <GroupChild24 alt="" src="/vector-17.svg" />
        <GroupChild25 alt="" src="/vector-17.svg" />
        <GroupChild26 alt="" src="/vector-17.svg" />
        <GroupChild27 alt="" src="/vector-17.svg" />
      </HelpCenterContactUsFaqParParent>
      <Am>8 AM - 5 PM , Monday - Saturday</Am>
      <AutQuaeConvallis>
        Aut, quae convallis minim cum ornare! Pede ut rem, totam dictum
        convallis.
      </AutQuaeConvallis>
      <VectorIcon17 alt="" src="/vector13.svg" />
      <Desktop2Child13 alt="" src="/group-79.svg" />
      <Desktop2Child14 alt="" src="/group-80.svg" />
      <Desktop2Child15 alt="" src="/group-81.svg" />
      <Desktop2Child16 alt="" src="/group-82.svg" />
      <VeroTemporMorbi>
        Vero, tempor morbi, adipiscing aliqua nonummy proident perferendis?
        Laboris lacus quidem repellendus quasi.
      </VeroTemporMorbi>
      <Desktop2Child17 />
      <PrivacyPolicy>{`PRIVACY POLICY    |     SUPPORT     |    TERMS & CONDITION`}</PrivacyPolicy>
      <Copyright>Copyright © 2022 Educator. All rights reserved.</Copyright>
    </DesktopRoot>
  );
};

export default Desktop;
